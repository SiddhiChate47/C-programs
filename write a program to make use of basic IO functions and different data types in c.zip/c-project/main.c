#include<stdio.h>
int main()
{
    int a;
    float b;
    double c;
    char d;
    printf("Enter a Character:");
    scanf("%c",&c);
    printf("Enter a INTEGER:");
    scanf("%d",&a);
    printf("Enter a value for Double:");
    scanf("%lf",&c);
    printf("Enter value for Float:");
    scanf("%f",&b);
    printf("Entered Name:%c\n",d);
    printf("Entered Integer:%d\n",a);
    printf("Entered Double:%lf\n",c);
    printf("Entered Float:%f\n",b);
    return 0;
}
