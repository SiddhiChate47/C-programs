#include<stdio.h>
int main()
{
    double a,b=3.14,c;
    printf("AREA OF CIRCLE\n");
    printf("Enter value of Radius:");
    scanf("%lf",&a);
    c = b * a * a;
        printf("Area of Circle:%lf",c);
    return 0;
}
