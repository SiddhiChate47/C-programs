#include<stdio.h>
int main()
{
    double a,b,c,d,f=3;
    printf("AVERAGE OF THREE NUMBERS\n");
    printf("Enter First Number:");
    scanf("%lf",&a);
    printf("Enter Second Number:");
    scanf("%lf",&b);
    printf("Enter Third Number:");
    scanf("%lf",&c);
    d = a + b + c / f;
        printf("Average:%lf",d);
    return 0;
}
