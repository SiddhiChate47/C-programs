#include <stdio.h>
int main() 
{
    double a;
    printf("Enter a Value:");
    scanf("%lf",&a);
    if (a > 0.00)
    {
        printf("%lf is Positive",a);
    }
    else if (a == 0.00)
    {
        printf("%lf is Zero",a);
    }
    else
    {
        printf("%lf is Negative",a);
    }
    return 0;
}
