#include <stdio.h>

int main() 
{
    int res1 = 10 + 5 * 2; 
    printf("1. Precedence Demonstration:\n");
    printf("   Expression: 10 + 5 * 2\n");
    printf("   Expected evaluation: 10 + (5 * 2) = 10 + 10 = 20\n");
    printf("   Result: %d\n\n", res1);
    int res2 = (10 + 5) * 2;
    printf("2. Using Parentheses to Override Precedence:\n");
    printf("   Expression: (10 + 5) * 2\n");
    printf("   Expected evaluation: (15) * 2 = 30\n");
    printf("   Result: %d\n\n", res2);
    int res3 = 20 / 5 * 2;
    printf("3. Left-to-Right Associativity:\n");
    printf("   Expression: 20 / 5 * 2\n");
    printf("   Expected evaluation: (20 / 5) * 2 = 4 * 2 = 8\n");
    printf("   Result: %d\n\n", res3);
    int a = 1, b = 2, c = 3;
    a = b = c; 
    printf("4. Right-to-Left Associativity:\n");
    printf("   Expression: a = b = c (where initial values were a=1, b=2, c=3)\n");
    printf("   Expected evaluation: b = c (b becomes 3), then a = b (a becomes 3)\n");
    printf("   Result: a = %d, b = %d, c = %d\n", a, b, c);
    return 0;
}
